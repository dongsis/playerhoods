import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Playerhoods',
  description: 'Tennis match organization platform',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'system-ui, sans-serif', margin: 0, padding: '1rem' }}>
        {children}
      </body>
    </html>
  )
}

# AI Prompt Template — playerhoods.com

Use this template at the start of ANY AI-assisted coding session.

---

This is an implementation discussion for playerhoods.com.

All implementations MUST strictly comply with playerhoods.com v1.2 Frozen Docs,
especially Match Invitation & Registration Spec v1.2.

If any behavior is not explicitly defined in the frozen docs,
ASK before implementing.

---

Context:
[Briefly describe what you want to implement here]

Relevant Docs:
[List the exact markdown files you are referencing]

Expected Output:
[SQL / RLS / RPC / Code / Review]

# Group Constitution (v1.2)

## Core Principle
Group is the ONLY relationship container in the system.

- All long-term human relationships exist only via Group membership.
- Match participation does NOT create or expand relationships.

## Boundaries
- Not in the same Group → no direct reachability.
- Match visibility or registration does NOT imply Group membership.

## Non-negotiables
- No Invite Set, no related group, no virtual group.
- Group membership lifecycle is authoritative.

# System Blueprint v1.2

## Scope
- Group-based human boundaries
- Match creation and participation
- Invite / Request flows
- Derived formed logic

## Explicit Non-goals
- Social feeds
- Implicit relationships
- Bulk invitations

Participation confirmation is dual-sided and field-driven.

The system does not model workflows through status,
but through explicit acceptance and approval fields,
with status serving only as a terminal summary.

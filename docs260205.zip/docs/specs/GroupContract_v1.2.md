# GroupContract v1

## Entity
Group represents an action boundary.

## Membership Status
- pending
- active
- removed

## Authority
- Boundary Keeper (BK) manages membership.
- Members have no implicit invite rights unless specified.

## Invariants
- Group is the only relationship container.
- No reinterpretation of membership states.

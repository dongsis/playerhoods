# MatchContract v1

## Match Status (Lifecycle Only)
- active
- cancelled
- archived

No derived or conditional states are allowed here.





## v1.2 Addendum — Dual Confirmation Fields

The following fields are appended to `match_participants`:

- user_accepted_at timestamptz null
- org_approved_at timestamptz null
- org_approved_by uuid null

These fields are used to express confirmation semantics
without introducing new status values.

---

### Confirmation Invariant

A participant is considered confirmed if and only if:

- status = 'confirmed'
- effective confirmation conditions are satisfied
  (see Status & Semantics v1.2)

Status MUST be synchronized by backend logic (RPC),
not inferred implicitly in client code.

---

### Compatibility

- Existing rows remain valid
- No enum or status reinterpretation occurs
- This addendum is backward-compatible with v1.1 data

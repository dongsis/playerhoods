# Repo Layout

docs/        → Authoritative specifications
supabase/    → Migrations and RLS
src/         → Application code
scripts/     → Verification & tooling

Docs are the source of truth.

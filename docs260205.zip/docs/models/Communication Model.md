# Communication Model

## Where communication happens
- Communication is always scoped to Group or MatchParticipant context.

## Restrictions
- Match does NOT create communication rights by itself.
- Register visibility does NOT grant communication access.

No user-to-user DM without an explicit Group context.

# Relationship Model

- User ↔ GroupMember defines all long-term relationships.
- MatchParticipant is temporary and does not alter relationships.
- Leaving or being removed from a Group ends the relationship.

No implicit or derived relationships are allowed.
